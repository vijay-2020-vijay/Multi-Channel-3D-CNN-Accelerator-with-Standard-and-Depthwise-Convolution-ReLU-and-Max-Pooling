import numpy as np
import cv2

# Input pixel file (single channel convolution output)
in_file = r"D:\memorey test file for cnn_accleretor\bram_dump6.txt"

# Image parameters
height = 254
width = 256
num_pixels = height * width  # 65024 pixels expected

# Step 1: Read pixel values
with open(in_file, "r") as f:
    lines = f.readlines()

# Convert to integers
lines = [int(x.strip()) for x in lines]

# Step 2: Sanity check
if len(lines) != num_pixels:
    raise ValueError(f"Pixel file has {len(lines)} values, but expected {num_pixels} ({height}x{width})")

# Step 3: Reshape into 2D matrix
img = np.array(lines, dtype=np.float32).reshape((height, width))

# Step 4: Normalize to 0–255 (for saving as image)
img_norm = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)
img_uint8 = img_norm.astype(np.uint8)

# Step 5: Save as PNG image
out_file = r"D:\python file\standard_convolution\multicha_convolution_output1.png"
cv2.imwrite(out_file, img_uint8)

print(f"Image generated successfully at: {out_file}")




