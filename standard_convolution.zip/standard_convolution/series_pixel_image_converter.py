
import numpy as np
import cv2

# File location (channel-wise pixel values)
pixel_file = r"D:\python file\standard_convolution\pixels_channelwise_amp.txt"

# Image parameters
height = 256
width = 256
num_pixels = height * width

# Step 1: Read pixel values
with open(pixel_file, "r") as f:
    lines = f.readlines()
lines = [int(x.strip()) for x in lines]

# Step 2: Extract B, G, R channels
B_vals = lines[:num_pixels]
G_vals = lines[num_pixels:2*num_pixels]
R_vals = lines[2*num_pixels:3*num_pixels]

# Step 3: Reshape channels
B = np.array(B_vals, dtype=np.uint8).reshape((height, width))
G = np.array(G_vals, dtype=np.uint8).reshape((height, width))
R = np.array(R_vals, dtype=np.uint8).reshape((height, width))

# Step 4: Merge channels back into image
img_reconstructed = cv2.merge([B, G, R])

# Step 5: Save image
out_file = r"D:\python file\standard_convolution\reconstructed_amp.png"
cv2.imwrite(out_file, img_reconstructed)

print("Image reconstructed successfully at:", out_file)
