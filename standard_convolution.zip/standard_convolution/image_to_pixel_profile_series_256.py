import cv2
import numpy as np

# Input and output paths
img_path = r"D:\python file\standard_convolution\amp.webp"
out_file = r"D:\python file\standard_convolution\pixels_channelwise.txt"

# Step 1: Read the image
img = cv2.imread(img_path)

# Step 2: Resize to 256x256
img_resized = cv2.resize(img, (256, 256))

# Step 3: Split into channels (OpenCV loads as BGR)
B, G, R = cv2.split(img_resized)

# Step 4: Write pixel values to file (channel-wise)
with open(out_file, "w") as f:
    # Write B channel
    for row in B:
        for val in row:
            f.write(f"{val}\n")
    # Write G channel
    for row in G:
        for val in row:
            f.write(f"{val}\n")
    # Write R channel
    for row in R:
        for val in row:
            f.write(f"{val}\n")

print("Pixel file generated successfully at:", out_file)
