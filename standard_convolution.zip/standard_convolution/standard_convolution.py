import numpy as np

# File location (channel-wise pixel values)
pixel_file = r"D:\python file\standard_convolution\pixels_channelwise_amp.txt"
out_file   = r"D:\python file\standard_convolution\convolution_output.txt"

# Image parameters
height = 256
width = 256
num_pixels = height * width

# Step 1: Read pixel values from file
with open(pixel_file, "r") as f:
    lines = f.readlines()
lines = [int(x.strip()) for x in lines]

# Step 2: Extract channels (R, G, B order)
R_vals = lines[:num_pixels]
G_vals = lines[num_pixels:2*num_pixels]
B_vals = lines[2*num_pixels:3*num_pixels]

# Step 3: Reshape into 2D matrices
R = np.array(R_vals, dtype=np.float32).reshape((height, width))
G = np.array(G_vals, dtype=np.float32).reshape((height, width))
B = np.array(B_vals, dtype=np.float32).reshape((height, width))

# Step 4: Stack into one 3D tensor [H, W, C]
img = np.stack([R, G, B], axis=-1)  # shape (256, 256, 3)

# Step 5: Define 3x3x3 kernel (example)
kernel = np.array([
    [[0, -1, 0],
     [-1, 5, -1],
     [0, -1, 0]],   # for Red

    [[0, -1, 0],
     [-1, 5, -1],
     [0, -1, 0]],   # for Green

    [[0, -1, 0],
     [-1, 5, -1],
     [0, -1, 0]]    # for Blue
], dtype=np.float32)  # shape (3,3,3)

# Step 6: Perform valid convolution (no padding)
out_h = height - 3 + 1  # 254
out_w = width - 3 + 1   # 254
output = np.zeros((out_h, out_w), dtype=np.float32)

for i in range(out_h):
    for j in range(out_w):
        region = img[i:i+3, j:j+3, :]       # 3x3x3 patch
        output[i, j] = np.sum(region * kernel)

# Step 7: Save output matrix (254x254x1) into text file
with open(out_file, "w") as f:
    for i in range(out_h):
        for j in range(out_w):
            f.write(f"{int(output[i,j])}\n")

print("Convolution completed. Output saved as 254x254x1 in:", out_file)


