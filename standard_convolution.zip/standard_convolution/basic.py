import numpy as np
import cv2

# Input pixel file (single channel convolution output)
in_file = r"D:\python file\standard_convolution\multicha_convlution_single_ch_out.txt"

# Image parameters
height = 254
width = 254
num_pixels = height * width

# Step 1: Read pixel values
with open(in_file, "r") as f:
    lines = f.readlines()
lines = [int(x.strip()) for x in lines]

# Step 2: Reshape into 2D matrix
img = np.array(lines, dtype=np.float32).reshape((height, width))

# Step 3: Normalize (optional, ensures values are in 0–255 for image saving)
img_norm = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX)
img_uint8 = img_norm.astype(np.uint8)

# Step 4: Save as image
out_file = r"D:\python file\standard_convolution\multicha_convolution_output.png"
cv2.imwrite(out_file, img_uint8)

print("Image generated successfully at:", out_file)



